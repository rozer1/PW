package sample;

public class SimpleRealTime {
}
